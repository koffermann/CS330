/*
Student Name: Kerrian Offermann
School: Southern New Hampshire University
Class: CS-330 [Comp Graphic and Visualization 22EW1]
*/

/*--- HEADERS ----------------------------------------------------------------------------*/

#include <iostream>  // cout, cerr
#include <cstdlib>  // EXIT_FAILURE

// GLEW and GLFW3 Headers
#include <GLEW\glew.h>
#include <GLFW\glfw3.h>

// GLM Math Header inclusions
#include <glm\glm.hpp>
#include <glm\gtc\matrix_transform.hpp>
#include <glm\gtc\type_ptr.hpp>
#include <cmath>

// Camera Header
#include <learnOpenGL\camera.h>
#include <vector>

// Texture Header
#include <SOIL2\SOIL2.h>



/*--- INITIALIZE VARIABLES ----------------------------------------------------------------------------*/

	/* Camera Controls
	W = FORWARD
	A = BACKWARD
	S = LEFT
	D = RIGHT
	Q = MOVE UPWARD
	E = MOVE DOWNWARD
	P = SWITCH BETWEEN PERSPECTIVE AND ORTHOGRAPHIC (HOLD P FOR ORTHOGRAPHIC VIEW)
	SCROLL MOUSE = ZOOM IN AND OUT
	ALT + LEFT MOUSE = PAN
	ALT + RIGHT MOUSE = ORBIT
	*/

using namespace std;

int width, height; // Variable for window's width and height
const double PI = 3.14159; // Defining pi
const float toRadians = PI / 180.0f; // Converting degrees to radians

namespace {
	// Declare View Matrix
	glm::mat4 viewMatrix;

	// Camera Field of View
	GLfloat fov = 45.0f;
	GLfloat fovMAX = 46.0f;
	GLfloat fovMIN = 44.00f;

	const float cameraZoom = 45.0f;
	const GLfloat SCROLL_SPEED = 0.30f;
	float MovementSpeed;

	// Define Camera Attributes
	glm::vec3 gCameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
	glm::vec3 gCameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
	glm::vec3 gCameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

	glm::vec3 cameraPosition = glm::vec3(0.0f, 0.0f, 3.0f);
	glm::vec3 target = glm::vec3(0.0f, 0.0f, 0.0f);
	glm::vec3 cameraDirection = glm::normalize(cameraPosition - target);
	glm::vec3 worldUp = glm::vec3(0.0f, 1.0f, 0.0f);
	glm::vec3 cameraRight = glm::normalize(glm::cross(worldUp, cameraDirection));
	glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
	glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);

	// Boolean array for keys and mouse buttons
	bool keys[1024];
	bool mouseButton[3];

	// Boolean to check camera transformation
	bool isPanning = false;
	bool isOrbiting = false;
	bool firstMouseMove = true; // Detect initial mouse movement
	bool perspective = false;

	// Radius, Pitch, and Yaw
	GLfloat radius = 3.0f;
	GLfloat rawYaw = 0.0f;
	GLfloat rawPitch = 0.0f;
	GLfloat degYaw;
	GLfloat degPitch;

	// Camera
	Camera gCamera(glm::vec3(0.0f, 0.0f, 3.0f));
	float gLastX = width / 2.0f;
	float gLastY = height / 2.0f;
	bool gFirstMouse = true;

	// Timing
	float gDeltaTime = 0.0f; // time between current frame and last frame
	float gLastFrame = 0.0f;

	// Cylinder Variables
	GLuint bottleVBO, bottleVAO; // bottle VAO variables
	float camX, camY, camZ; // view or camera location (x,y,z)
	float triLocX, triLocY, triLocZ; // triangle location (x,y,z)
	GLuint mvLoc, projLoc; // mvp uniform reference variables
	float aspectRatio; // for p matrix aspect ratio
	glm::mat4 pMat, vMat, mMat, mvMat; // mvp variables


	GLfloat lastX = width/2, lastY = height/2, xChange, yChange;

	// Light Source Position
	glm::vec3 lightPosition1(0.0f, 1.5f, 0.0f);
	glm::vec3 lightPosition2(-1.5f, 0.0f, 1.0f);

}

glm::vec3 getTarget();

// Declare Input Callback Function prototypes
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void mouse_button_callback(GLFWwindow* window, int button, int action, int mode);

// Camera Transformation Prototype
void TransformCamera();
void initCamera();



GLenum glCheckError_(const char* file, int line)
{
	GLenum errorCode;
	while ((errorCode = glGetError()) != GL_NO_ERROR)
	{
		std::string error;
		switch (errorCode)
		{
		case GL_INVALID_ENUM:                  error = "INVALID_ENUM"; break;
		case GL_INVALID_VALUE:                 error = "INVALID_VALUE"; break;
		case GL_INVALID_OPERATION:             error = "INVALID_OPERATION"; break;
		case GL_STACK_OVERFLOW:                error = "STACK_OVERFLOW"; break;
		case GL_STACK_UNDERFLOW:               error = "STACK_UNDERFLOW"; break;
		case GL_OUT_OF_MEMORY:                 error = "OUT_OF_MEMORY"; break;
		case GL_INVALID_FRAMEBUFFER_OPERATION: error = "INVALID_FRAMEBUFFER_OPERATION"; break;
		}
		std::cout << error << " | " << file << " (" << line << ")" << std::endl;
	}
	return errorCode;
}

#define glCheckError() glCheckError_(__FILE__, __LINE__) 



/*--- DRAW FUNCTION ----------------------------------------------------------------------------*/
// Setting up how different objects will be drawn when called later

// Function to draw dice

void dice_draw()
{
	GLenum mode = GL_TRIANGLES;
	GLsizei indices = 20;
	glDrawElements(mode, indices, GL_UNSIGNED_BYTE, nullptr);
}

// Function to draw a cube

void cube_draw()
{
	GLenum mode = GL_TRIANGLES;
	GLsizei indices = 6;
	glDrawElements(mode, indices, GL_UNSIGNED_BYTE, nullptr);
}

// Function to draw table
void table_draw()
{
	GLenum mode = GL_TRIANGLES;
	GLsizei indices = 12;
	glDrawElements(mode, indices, GL_UNSIGNED_BYTE, nullptr);
}

// Function to draw ceiling light
unsigned int lightVAO = 0;
unsigned int torus_indexCount1;

static void light_draw(int numc, int numt)

{
	if (lightVAO == 0)
	{
		glGenVertexArrays(1, &lightVAO);

		unsigned int vbo, ebo;
		glGenBuffers(1, &vbo);
		glGenBuffers(1, &ebo);

		std::vector<glm::vec3> positions;
		std::vector<glm::vec2> uv;
		std::vector<glm::vec3> normals;
		std::vector<unsigned int> indices;

		const unsigned int X_SEGMENTS = 16;
		const unsigned int Y_SEGMENTS = 16;
		const unsigned int Z_SEGMENTS = 16;
		const float PI = 3.14159265359f;
		const float TWO_PI = PI * 2;

		for (unsigned int x = 0; x <= X_SEGMENTS / 2; ++x) {
			for (unsigned int y = 0; y <= Y_SEGMENTS; ++y) {
				for (unsigned int z = 0; z <= Z_SEGMENTS; z++) {
					float xSegment = (float)x / (float)X_SEGMENTS;
					float ySegment = (float)y / (float)Y_SEGMENTS;

					xSegment = (x + z) % numc + 0.5;
					ySegment = y % numt;

					float xPos = (1 + 0.1 * std::cos(xSegment * TWO_PI / numc)) * cos(ySegment * TWO_PI / numt);
					float yPos = (1 + 0.1 * std::cos(xSegment * TWO_PI / numc)) * sin(ySegment * TWO_PI / numt);
					float zPos = 0.1 * std::sin(xSegment * TWO_PI / numc);

					positions.push_back(glm::vec3(xPos, yPos, zPos));
					uv.push_back(glm::vec2(xSegment, ySegment));
					normals.push_back(glm::vec3(xPos, yPos, zPos));
				}
			}
		}

		bool oddRow = false;
		for (unsigned int y = 0; y < Y_SEGMENTS; ++y)
		{
			if (!oddRow) // even rows: y == 0, y == 2; and so on
			{
				for (unsigned int x = 0; x <= X_SEGMENTS; ++x)
				{
					indices.push_back(y * (X_SEGMENTS + 1) + x);
					indices.push_back((y + 1) * (X_SEGMENTS + 1) + x);
				}
			}
			else
			{
				for (int x = X_SEGMENTS; x >= 0; --x)
				{
					indices.push_back((y + 1) * (X_SEGMENTS + 1) + x);
					indices.push_back(y * (X_SEGMENTS + 1) + x);
				}
			}
			oddRow = !oddRow;
		}

		torus_indexCount1 = static_cast<unsigned int>(indices.size());

		std::vector<float> data;
		for (unsigned int i = 0; i < positions.size(); ++i)
		{
			data.push_back(positions[i].x);
			data.push_back(positions[i].y);
			data.push_back(positions[i].z);
			if (normals.size() > 0)
			{
				data.push_back(normals[i].x);
				data.push_back(normals[i].y);
				data.push_back(normals[i].z);
			}
			if (uv.size() > 0)
			{
				data.push_back(uv[i].x);
				data.push_back(uv[i].y);
			}
		}
		glBindVertexArray(lightVAO);
		glBindBuffer(GL_ARRAY_BUFFER, vbo);
		glBufferData(GL_ARRAY_BUFFER, data.size() * sizeof(float), &data[0], GL_STATIC_DRAW);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), &indices[0], GL_STATIC_DRAW);
		unsigned int stride = (3 + 2 + 3) * sizeof(float);
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
		glEnableVertexAttribArray(2);
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
	}

	glBindVertexArray(lightVAO);
	glDrawElements(GL_TRIANGLE_STRIP, torus_indexCount1, GL_UNSIGNED_INT, 0);
}


// Function to draw pillow
unsigned int pillowVAO = 0;
unsigned int torus_indexCount;

static void pillow_draw(int numc, int numt)

{
	if (pillowVAO == 0)
	{
		glGenVertexArrays(1, &pillowVAO);

		unsigned int vbo, ebo;
		glGenBuffers(1, &vbo);
		glGenBuffers(1, &ebo);

		std::vector<glm::vec3> positions;
		std::vector<glm::vec2> uv;
		std::vector<glm::vec3> normals;
		std::vector<unsigned int> indices;

		const unsigned int X_SEGMENTS = 34;
		const unsigned int Y_SEGMENTS = 36;
		const unsigned int Z_SEGMENTS = 36;
		const float PI = 3.14159265359f;
		const float TWO_PI = PI * 2;

		for (unsigned int x = 0; x <= X_SEGMENTS/2; ++x) {
			for (unsigned int y = 0; y <= Y_SEGMENTS; ++y) {
				for (unsigned int z = 0; z <= Z_SEGMENTS; z++) {
					float xSegment = (float)x / (float)X_SEGMENTS;
					float ySegment = (float)y / (float)Y_SEGMENTS;
					float zSegment = (float)z/ (float)Z_SEGMENTS;

					xSegment = (x + z) % numc + 0.5;
					ySegment = y % numt;

					float xPos = (1 + 0.1 * std::cos(xSegment * TWO_PI / numc)) * cos(ySegment * TWO_PI / numt);
					float yPos = (1 + 0.1 * std::cos(xSegment * TWO_PI / numc)) * sin(ySegment * TWO_PI / numt);
					float zPos = 0.1 * std::sin(xSegment * TWO_PI / numc);

					positions.push_back(glm::vec3(xPos, yPos, zPos));
					uv.push_back(glm::vec3(xSegment, ySegment, zSegment));
					normals.push_back(glm::vec3(xPos, yPos, zPos));
				}
			}
		}

		bool oddRow = false;
		for (unsigned int y = 0; y < Y_SEGMENTS; ++y)
		{
			if (!oddRow) // even rows: y == 0, y == 2; and so on
			{
				for (unsigned int x = 0; x <= X_SEGMENTS; ++x)
				{
					indices.push_back(y * (X_SEGMENTS + 1) + x);
					indices.push_back((y + 1) * (X_SEGMENTS + 1) + x);
				}
			}
			else
			{
				for (int x = X_SEGMENTS; x >= 0; --x)
				{
					indices.push_back((y + 1) * (X_SEGMENTS + 1) + x);
					indices.push_back(y * (X_SEGMENTS + 1) + x);
				}
			}
			oddRow = !oddRow;
		}

		torus_indexCount = static_cast<unsigned int>(indices.size());

		std::vector<float> data;
		for (unsigned int i = 0; i < positions.size(); ++i)
		{
			data.push_back(positions[i].x);
			data.push_back(positions[i].y);
			data.push_back(positions[i].z);
			if (normals.size() > 0)
			{
				data.push_back(normals[i].x);
				data.push_back(normals[i].y);
				data.push_back(normals[i].z);
			}
			if (uv.size() > 0)
			{
				data.push_back(uv[i].x);
				data.push_back(uv[i].y);
			}
		}
		glBindVertexArray(pillowVAO);
		glBindBuffer(GL_ARRAY_BUFFER, vbo);
		glBufferData(GL_ARRAY_BUFFER, data.size() * sizeof(float), &data[0], GL_STATIC_DRAW);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), &indices[0], GL_STATIC_DRAW);
		unsigned int stride = (3 + 2 + 3) * sizeof(float);
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
		glEnableVertexAttribArray(2);
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
	}

	glBindVertexArray(pillowVAO);
	glDrawElements(GL_TRIANGLE_STRIP, torus_indexCount, GL_UNSIGNED_INT, 0);
}


// Function to draw ball
unsigned int sphereVAO = 0;
unsigned int indexCount;

void ball_draw()
{
	if (sphereVAO == 0)
	{
		glGenVertexArrays(1, &sphereVAO);

		unsigned int vbo, ebo;
		glGenBuffers(1, &vbo);
		glGenBuffers(1, &ebo);

		std::vector<glm::vec3> positions;
		std::vector<glm::vec2> uv;
		std::vector<glm::vec3> normals;
		std::vector<unsigned int> indices;

		const unsigned int X_SEGMENTS = 64;
		const unsigned int Y_SEGMENTS = 64;
		const float PI = 3.14159265359f;
		for (unsigned int x = 0; x <= X_SEGMENTS; ++x)
		{
			for (unsigned int y = 0; y <= Y_SEGMENTS; ++y)
			{
				float xSegment = (float)x / (float)X_SEGMENTS;
				float ySegment = (float)y / (float)Y_SEGMENTS;
				float xPos = std::cos(xSegment * 2.0f * PI) * std::sin(ySegment * PI);
				float yPos = std::cos(ySegment * PI);
				float zPos = std::sin(xSegment * 2.0f * PI) * std::sin(ySegment * PI);

				positions.push_back(glm::vec3(xPos, yPos, zPos));
				uv.push_back(glm::vec2(xSegment, ySegment));
				normals.push_back(glm::vec3(xPos, yPos, zPos));
			}
		}

		bool oddRow = false;
		for (unsigned int y = 0; y < Y_SEGMENTS; ++y)
		{
			if (!oddRow) // even rows: y == 0, y == 2; and so on
			{
				for (unsigned int x = 0; x <= X_SEGMENTS; ++x)
				{
					indices.push_back(y * (X_SEGMENTS + 1) + x);
					indices.push_back((y + 1) * (X_SEGMENTS + 1) + x);
				}
			}
			else
			{
				for (int x = X_SEGMENTS; x >= 0; --x)
				{
					indices.push_back((y + 1) * (X_SEGMENTS + 1) + x);
					indices.push_back(y * (X_SEGMENTS + 1) + x);
				}
			}
			oddRow = !oddRow;
		}
		indexCount = static_cast<unsigned int>(indices.size());

		std::vector<float> data;
		for (unsigned int i = 0; i < positions.size(); ++i)
		{
			data.push_back(positions[i].x);
			data.push_back(positions[i].y);
			data.push_back(positions[i].z);
			if (normals.size() > 0)
			{
				data.push_back(normals[i].x);
				data.push_back(normals[i].y);
				data.push_back(normals[i].z);
			}
			if (uv.size() > 0)
			{
				data.push_back(uv[i].x);
				data.push_back(uv[i].y);
			}
		}
		glBindVertexArray(sphereVAO);
		glBindBuffer(GL_ARRAY_BUFFER, vbo);
		glBufferData(GL_ARRAY_BUFFER, data.size() * sizeof(float), &data[0], GL_STATIC_DRAW);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), &indices[0], GL_STATIC_DRAW);
		unsigned int stride = (3 + 2 + 3) * sizeof(float);
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
		glEnableVertexAttribArray(2);
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
	}

	glBindVertexArray(sphereVAO);
	glDrawElements(GL_TRIANGLE_STRIP, indexCount, GL_UNSIGNED_INT, 0);
}



/*--- SHADERS ----------------------------------------------------------------------------*/
// Create default shader program

	// Create and Compile Shaders
static GLuint CompileShader(const string& source, GLuint shaderType)
{
	// Create Shader object
	GLuint shaderID = glCreateShader(shaderType);
	const char* src = source.c_str();

	// Attach source code to Shader object
	glShaderSource(shaderID, 1, &src, nullptr);

	// Compile Shader
	glCompileShader(shaderID);

	// Return ID of Compiled shader
	return shaderID;
}

// Create Program Object
static GLuint CreateShaderProgram(const string& vertexShader, const string& fragmentShader)
{
	// Compile vertex shader
	GLuint vertexShaderComp = CompileShader(vertexShader, GL_VERTEX_SHADER);

	// Compile fragment shader
	GLuint fragmentShaderComp = CompileShader(fragmentShader, GL_FRAGMENT_SHADER);

	// Create program object
	GLuint shaderProgram = glCreateProgram();

	// Attach vertex and fragment shaders to program object
	glAttachShader(shaderProgram, vertexShaderComp);
	glAttachShader(shaderProgram, fragmentShaderComp);

	// Link shaders to create executable
	glLinkProgram(shaderProgram);

	// Delete compiled vertex and fragment shaders
	glDeleteShader(vertexShaderComp);
	glDeleteShader(fragmentShaderComp);

	// Return Shader Program
	return shaderProgram;
}



/*--- MAIN FUNCTION ----------------------------------------------------------------------------*/
// Create window, functions, vertices/indices, VAOs, VBOs, EBOs, textures, and different shaders.
// The core of the program will be in this function.

int main(void)
{
	width = 800; height = 600;

	GLFWwindow* window;

	/* Initialize the library */
	if (!glfwInit())
		return -1;

	/* Create a windowed mode window and its OpenGL context */
	window = glfwCreateWindow(width, height, "CS-330 | Final Project | Kerrian Offermann", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	glGetError();

	// Set input callback functions
	glfwSetKeyCallback(window, key_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetMouseButtonCallback(window, mouse_button_callback);
	glfwSetScrollCallback(window, scroll_callback);

	/* Make the window's context current */
	glfwMakeContextCurrent(window);

	// Initialize GLEW
	if (glewInit() != GLEW_OK)
		cout << "Error!" << endl;


	// ----------------------------------------------------------------------

	// Define lamp vertices
	GLfloat lamp_vertices[] = {

		// Coordinates     
		-0.5, -0.5, 0.0,
		-0.5, 0.5, 0.0,
		 0.5, -0.5, 0.0f,
		 0.5, 0.5, 0.0,
	};

	// Define lamp indices
	GLubyte lamp_indices[] = {
		0, 1, 2,
		1, 2, 3
	};

	// Define dice vertices
	GLfloat dice_vertices[] = {

		// Pyramid sides

		// Coordinates          // Colors          // Textures    // Normals
		-1.0f, -1.0f, -1.0f,   0.0f, 1.0f, 1.0f,   1.0f, 0.0f,    -1.0f, 0.0f, 0.0f,    // 0 | Back
		1.0f, -1.0f, -1.0f,   1.0f, 1.0f, 0.0f,    0.0f, 0.0f,    -1.0f, 0.0f, 0.0f,    // 1 | Back
		0.0f, 1.0f, 0.0f,     1.0f, 1.0f, 1.0f,    0.5f, 1.0f,    -1.0f, 0.0f, 0.0f,    // 2 | Back

		1.0f, -1.0f, -1.0f,   1.0f, 1.0f, 0.0f,    1.0f, 0.0f,    0.0f, 0.0f, 1.0f,    // 3 | Right 
		1.0f, -1.0f, 1.0f,    1.0f, 0.0f, 1.0f,    0.0f, 0.0f,    0.0f, 0.0f, 1.0f,    // 4 | Right 
		0.0f, 1.0f, 0.0f,     1.0f, 1.0f, 1.0f,    0.5f, 1.0f,    0.0f, 0.0f, 1.0f,    // 5 | Right 

		1.0f, -1.0f, 1.0f,    1.0f, 0.0f, 1.0f,    1.0f, 0.0f,    0.0f, 0.0f, 1.0f,    // 6 | Front - Facing Camera
		-1.0f, -1.0f, 1.0f,    0.0f, 0.0f, 1.0f,   0.0f, 0.0f,    0.0f, 0.0f, 1.0f,    // 7 | Front - Facing Camera
		0.0f, 1.0f, 0.0f,     1.0f, 1.0f, 1.0f,    0.5f, 1.0f,    0.0f, 0.0f, 1.0f,    // 8 | Front - Facing Camera

		-1.0f, -1.0f, 1.0f,   0.0f, 0.0f, 1.0f,   1.0f, 0.0f,     -1.0f, 0.0f, 0.0f,    // 9 | Left
		-1.0f, -1.0f, -1.0f,   0.0f, 1.0f, 1.0f,   0.0f, 0.0f,    -1.0f, 0.0f, 0.0f,    // 10 | Left
		 0.0f, 1.0f, 0.0f,     1.0f, 1.0f, 1.0f,   0.5f, 1.0f,   -1.0f, 0.0f, 0.0f,    // 11 | Left


		// Base of Pyramid

		// Coordinates          // Colors          // Textures    //Normals
		-1.0f, -1.0f, -1.0f,   0.0f, 1.0f, 1.0f,   1.0f, 0.0f,    0.0f, -1.0f, 0.0f,    // 12 | Bottom
		1.0f, -1.0f, -1.0f,   1.0f, 1.0f, 0.0f,    0.0f, 0.0f,    0.0f, -1.0f, 0.0f,    // 13 | Bottom
		-1.0f, -1.0f, 1.0f,    0.0f, 0.0f, 1.0f,   0.5f, 1.0f,    0.0f, -1.0f, 0.0f,    // 14 | Bottom

		1.0f, -1.0f, -1.0f,   1.0f, 1.0f, 0.0f,    1.0f, 0.0f,    0.0f, -1.0f, 0.0f,    // 15 | Bottom
		-1.0f, -1.0f, 1.0f,    0.0f, 0.0f, 1.0f,   0.0f, 0.0f,    0.0f, -1.0f, 0.0f,    // 16 | Bottom
		1.0f, -1.0f, 1.0f,    1.0f, 0.0f, 1.0f,    0.5f, 1.0f,    0.0f, -1.0f, 0.0f     // 17 | Bottom
	};

	// Define dice indices
	GLubyte dice_indices[] = {
		0, 1, 2,
		3, 4, 5,
		6, 7, 8,
		9, 10, 11,
		12, 13, 14,
		15, 16, 17
	};

	// Define table vertices
	GLfloat table_vertices[] = {
		// Plane - Table

		// Coordinates        // Colors            // Textures    // Normals
		-2.0f, -2.0f, -2.0f,   1.0f, 0.0f, 0.0f,    0.0f, 0.0f,    0.0f, 1.0f, 1.0f, // Index 0
		 2.0f, -2.0f, -2.0f,   1.0f, 1.0f, 0.0f,    0.0f, 1.0f,    0.0f, 1.0f, 1.0f, // Index 1
		 2.0f, -2.0f, 2.0f,    0.0f, 1.0f, 0.0f,    1.0f, 0.0f,    0.0f, -1.0f, -1.0f, // Index 2
		-2.0f, -2.0f, 2.0f,    0.0f, 0.0f, 1.0f,    1.0f, 1.0f,    0.0f, -1.0f, -1.0f // Index 3

		-2.0f, -2.5f, -2.0f,   1.0f, 0.0f, 0.0f,    0.0f, 0.0f,    0.0f, 1.0f, 1.0f, // Index 4
		 2.0f, -2.5f, -2.0f,   1.0f, 1.0f, 0.0f,    0.0f, 1.0f,    0.0f, 1.0f, 1.0f, // Index 5
		 2.0f, -2.5f, 2.0f,    0.0f, 1.0f, 0.0f,    1.0f, 0.0f,    0.0f, -1.0f, -1.0f, // Index 6
		-2.0f, -2.5f, 2.0f,   0.0f, 0.0f, 1.0f,    1.0f, 1.0f,    0.0f, -1.0f, -1.0f // Index 7


	};

	// Define table indices
	GLubyte table_indices[] = {
		0, 1, 2,
		0, 2, 3,
		4, 5, 6,
		4, 6, 7,

		0, 4, 7,
		3, 7, 0,

		3, 7, 2,
		2, 6, 7,

		2, 6, 5,
		1, 5, 2,

		0, 4, 1,
		1, 5, 4
	};

	// Define bottle vertices
	GLfloat bottle_vertices[] = {
		// Cylinder - base of bottle

		// Coordinates          // Colors          // Textures    // Normals
		0.0f, 0.0f, 0.0f,    1.0f, 1.0f, 1.0f,    1.0f, 1.0f,    0.0f, 0.0f, 1.0f,  // Index 0 
		0.5f, 0.866f, 0.0f,  0.0f, 1.0f, 0.0f,    0.0f, 0.0f,    0.0f, 0.0f, 1.0f,  // Index 1 
		1.0f, 0.0f, 0.0f,    0.0f, 0.0f, 1.0f,    0.0f, 1.0f,    0.0f, 0.0f, 1.0f,  // Index 2 
		0.5f, 0.866f, 0.0f,  0.0f, 1.0f, 0.0f,    1.0f, 1.0f,    0.0f, 0.0f, 1.0f,  // Index 3
		0.5f, 0.866f, -2.0f, 0.0f, 1.0f, 0.0f,    1.0f, 0.0f,    0.0f, 0.0f, 1.0f,  // Index 4 
		1.0f, 0.0f, 0.0f,    0.0f, 0.0f, 1.0f,    0.0f, 1.0f,    -1.0f, 0.0f, 0.0f,  // Index 5 
		1.0f, 0.0f, 0.0f,    0.0f, 0.0f, 1.0f,    0.0f, 1.0f,    -1.0f, 0.0f, 0.0f,  // Index 6
		1.0f, 0.0f, -2.0f,   0.0f, 0.0f, 1.0f,    1.0f, 0.0f,    -1.0f, 0.0f, 0.0f,  // Index 7
		0.5f, 0.866f, -2.0f, 0.0f, 1.0f, 0.0f,    1.0f, 1.0f,    -1.0f, 0.0f, 0.0f, // Index 8 

	};

	// Define bottle cap vertices
	GLfloat cap_vertices[] = {
		// Cylinder - cap of bottle

		// Coordinates          // Colors          // Textures    // Normals
		0.0f, 0.0f, 0.0f,      1.0f, 0.0f, 0.0f,    0.5f, 0.0f,    0.0f, 0.0f, 1.0f,  // Index 0 
		0.5f, 0.866f, 0.0f,    0.0f, 1.0f, 0.0f,    0.5f, 0.0f,    0.0f, 0.0f, 1.0f,  // Index 1 
		1.0f, 0.0f, 0.0f,      0.0f, 0.0f, 1.0f,    1.0f, 0.0f,    0.0f, 0.0f, 1.0f,  // Index 2 
		0.5f, 0.866f, 0.0f,    0.0f, 1.0f, 0.0f,    0.5f, 1.0f,    0.0f, 0.0f, 1.0f,  // Index 3
		0.5f, 0.866f, -2.0f,   0.0f, 1.0f, 0.0f,    1.0f, 0.0f,    -1.0f, 0.0f, 0.0f,  // Index 4 
		1.0f, 0.0f, 0.0f,      0.0f, 0.0f, 1.0f,    0.0f, 1.0f,    -1.0f, 0.0f, 0.0f,  // Index 5 
		1.0f, 0.0f, 0.0f,      0.0f, 0.0f, 1.0f,    0.0f, 1.0f,    -1.0f, 0.0f, 0.0f,  // Index 6
		1.0f, 0.0f, -2.0f,     0.0f, 0.0f, 1.0f,    1.0f, 1.0f,    -1.0f, 0.0f, 0.0f,  // Index 7
		0.5f, 0.866f, -2.0f,   0.0f, 1.0f, 0.0f,    1.0f, 1.0f,    -1.0f, 0.0f, 0.0f  // Index 8 

	};

	// Define ball vertices
	GLfloat ball_vertices[] = {

		// Coordinates          // Colors          // Textures    // Normals
		0.0f, 0.0f, 0.0f,      1.0f, 0.0f, 0.0f,    0.5f, 0.0f,    1.0f, 1.0f, 1.0f,  // Index 0 
		0.5f, 0.866f, 0.0f,    0.0f, 1.0f, 0.0f,    0.5f, 0.0f,    1.0f, 1.0f, 1.0f,  // Index 1 
		1.0f, 0.0f, 0.0f,      0.0f, 0.0f, 1.0f,    1.0f, 0.5f,    1.0f, 1.0f, 1.0f,  // Index 2 
		0.5f, 0.866f, 0.0f,    0.0f, 1.0f, 0.0f,    0.5f, 1.0f,    1.0f, 1.0f, 1.0f,  // Index 3
		0.5f, 0.866f, -2.0f,   0.0f, 1.0f, 0.0f,    1.0f, 0.0f,    0.0f, 0.0f, 0.0f,  // Index 4 
		1.0f, 0.0f, 0.0f,      0.0f, 0.0f, 1.0f,    0.0f, 1.0f,    0.0f, 0.0f, 0.0f,  // Index 5 
		1.0f, 0.0f, 0.0f,      0.0f, 0.0f, 1.0f,    0.0f, 1.0f,    0.0f, 0.0f, 0.0f,  // Index 6
		1.0f, 0.0f, -2.0f,     0.0f, 0.0f, 1.0f,    1.0f, 0.0f,    0.0f, 0.0f, 0.0f,  // Index 7
		0.5f, 0.866f, -2.0f,   0.0f, 1.0f, 0.0f,    1.0f, 0.5f,    0.0f, 0.0f, 0.0f  // Index 8 

	};


	// Plane position
	glm::vec3 planePositions[] = {
		glm::vec3(0.0f,  0.0f,  0.5f),
		glm::vec3(0.5f,  0.0f,  0.0f),
		glm::vec3(0.0f,  0.0f,  -0.5f),
		glm::vec3(-0.5f, 0.0f,  0.0f),
		glm::vec3(0.0f, 0.5f,  0.0f),
		glm::vec3(0.0f, -0.5f,  0.0f)
	};

	// Plane rotation
	glm::float32 planeRotations[] = {
		0.0f, 90.0f, 180.0f, -90.0f, -90.f, 90.f
	};

	// Position torus to lay flat
	glm::vec3 torus_planePositions[] = {
		glm::vec3(0.0f,  0.0f,  0.5f),
		glm::vec3(0.5f,  0.0f,  0.0f),
		glm::vec3(0.0f,  0.0f,  -0.5f),
		glm::vec3(0.5f, 0.0f,  0.0f),
		glm::vec3(0.0f, 0.5f,  0.0f),
		glm::vec3(0.0f, -0.5f,  0.0f)
	};

	// Position how the torus will rotate
	glm::float32 torus_planeRotations[] = {
		240.0f, 180.0f, 180.0f, 180.0f, 180.0f, 180.0f
	};




	// --------------------------------------------------------------


 
	//Enable Z-Depth Buffer
	glEnable(GL_DEPTH_TEST);

	// Wireframe mode (currently turned off)
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	GLuint diceVBO, diceEBO, diceVAO, lampVBO, lampEBO, lampVAO, tableVBO, tableEBO, tableVAO, bottleVAO, bottleVBO, capVAO, capVBO;

	glGenBuffers(1, &diceVBO); // Create VBO
	glGenBuffers(1, &diceEBO); // Create EBO
	glGenVertexArrays(1, &diceVAO); // Create VOA

	glGenBuffers(1, &lampVBO); // Create VBO
	glGenBuffers(1, &lampEBO); // Create EBO
	glGenVertexArrays(1, &lampVAO); // Create VOA

	glGenBuffers(1, &tableVBO); // Create VBO
	glGenBuffers(1, &tableEBO); // Create EBO
	glGenVertexArrays(1, &tableVAO); // Create VOA

	glGenBuffers(1, &bottleVBO); // Create VBO
	glGenVertexArrays(1, &bottleVAO); // Create VAO

	glGenBuffers(1, &capVBO); // Create VBO
	glGenVertexArrays(1, &capVAO); // Create VAO


	// -----------------------------------------------------------


	glBindVertexArray(diceVAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, diceVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, diceEBO); // Select EBO
	glBufferData(GL_ARRAY_BUFFER, sizeof(dice_vertices), dice_vertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(dice_indices), dice_indices, GL_STATIC_DRAW); // Load indices 
	// Specify attribute location and layout to GPU
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)


	// -----------------------------------------------------------


	glBindVertexArray(lampVAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, lampVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, lampEBO); // Select EBO
	glBufferData(GL_ARRAY_BUFFER, sizeof(lamp_vertices), lamp_vertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(lamp_indices), lamp_indices, GL_STATIC_DRAW); // Load indices 
	// Specify attribute location and layout to GPU
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)


	// -----------------------------------------------------------


	glBindVertexArray(tableVAO);

	glBindBuffer(GL_ARRAY_BUFFER, tableVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, tableEBO); // Select EBO
	glBufferData(GL_ARRAY_BUFFER, sizeof(table_vertices), table_vertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(table_indices), table_indices, GL_STATIC_DRAW); // Load indices 
	// Specify attribute location and layout to GPU
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glBindVertexArray(0);


	// -----------------------------------------------------------


	glBindVertexArray(bottleVAO);

	glBindBuffer(GL_ARRAY_BUFFER, bottleVBO); // Enable VBO	
	glBufferData(GL_ARRAY_BUFFER, sizeof(bottle_vertices), bottle_vertices, GL_STATIC_DRAW); // Copy Vertex data to VBO
	// Specify attribute location and layout to GPU
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0); // Associate VBO with VA (Vertex Attribute)
	glEnableVertexAttribArray(0); // Enable VA
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(1); // Enable VA
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glBindVertexArray(0); // Unbind VAO (Optional but recommended)


	// -----------------------------------------------------------



	glBindVertexArray(capVAO);

	glBindBuffer(GL_ARRAY_BUFFER, capVBO); // Enable VBO	
	glBufferData(GL_ARRAY_BUFFER, sizeof(cap_vertices), cap_vertices, GL_STATIC_DRAW); // Copy Vertex data to VBO
	// Specify attribute location and layout to GPU
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0); // Associate VBO with VA (Vertex Attribute)
	glEnableVertexAttribArray(0); // Enable VA
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(1); // Enable VA
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glBindVertexArray(0); // Unbind VAO (Optional but recommended)




	// --- LOAD TEXTURE ----------------------------------------------------------------

	// Dice Texture
	int diceWidth, diceHeight;
	unsigned char* diceimage = SOIL_load_image("C:/Users/koffe/Dropbox/PC/Desktop/Kerri/SNHU - 1452874/22EW1/CS330 Comp Graphic and Visualization/OpenGL_Projects/Dependencies/include/dthree.jpg", &diceWidth, &diceHeight, 0, SOIL_LOAD_RGB);

	//flipImageVertically(diceimage, diceWidth, diceHeight, 0);

	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	// Generate Textures
	GLuint diceTexture;
	glGenTextures(1, &diceTexture);
	glBindTexture(GL_TEXTURE_2D, diceTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, diceWidth, diceHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, diceimage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(diceimage);
	glBindTexture(GL_TEXTURE_2D, 0); // Unbind or close texture object


	// Table Texture
	int tableWidth, tableHeight;
	unsigned char* tableimage = SOIL_load_image("C:/Users/koffe/Dropbox/PC/Desktop/Kerri/SNHU - 1452874/22EW1/CS330 Comp Graphic and Visualization/OpenGL_Projects/Dependencies/include/table.jpg", &tableWidth, &tableHeight, 0, SOIL_LOAD_RGB);

	GLuint tableTexture;
	glGenTextures(1, &tableTexture);
	glBindTexture(GL_TEXTURE_2D, tableTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, tableWidth, tableHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, tableimage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(tableimage);
	glBindTexture(GL_TEXTURE_2D, 0);



	// Bottle Texture
	int bottleWidth, bottleHeight;
	unsigned char* bottleimage = SOIL_load_image("C:/Users/koffe/Dropbox/PC/Desktop/Kerri/SNHU - 1452874/22EW1/CS330 Comp Graphic and Visualization/OpenGL_Projects/Dependencies/include/water.jpg", &bottleWidth, &bottleHeight, 0, SOIL_LOAD_RGB);

	GLuint bottleTexture;
	glGenTextures(1, &bottleTexture);
	glBindTexture(GL_TEXTURE_2D, bottleTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, bottleWidth, bottleHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, bottleimage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(bottleimage);
	glBindTexture(GL_TEXTURE_2D, 0);



	// Cap Texture
	int capWidth, capHeight;
	unsigned char* capimage = SOIL_load_image("C:/Users/koffe/Dropbox/PC/Desktop/Kerri/SNHU - 1452874/22EW1/CS330 Comp Graphic and Visualization/OpenGL_Projects/Dependencies/include/cap.jpg", &bottleWidth, &bottleHeight, 0, SOIL_LOAD_RGB);

	GLuint capTexture;
	glGenTextures(1, &capTexture);
	glBindTexture(GL_TEXTURE_2D, capTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, bottleWidth, bottleHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, capimage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(capimage);
	glBindTexture(GL_TEXTURE_2D, 0);



	// Pillow Texture
	int pillowWidth, pillowHeight;
	unsigned char* pillowImage = SOIL_load_image("C:/Users/koffe/Dropbox/PC/Desktop/Kerri/SNHU - 1452874/22EW1/CS330 Comp Graphic and Visualization/OpenGL_Projects/Dependencies/include/pinkfur.jpg", &pillowWidth, &pillowHeight, 0, SOIL_LOAD_RGB);

	GLuint pillowTexture;
	glGenTextures(1, &pillowTexture);
	glBindTexture(GL_TEXTURE_2D, pillowTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, pillowWidth, pillowHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, pillowImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(pillowImage);
	glBindTexture(GL_TEXTURE_2D, 0);



	// Ball Texture
	int ballWidth, ballHeight;
	unsigned char* ballImage = SOIL_load_image("C:/Users/koffe/Dropbox/PC/Desktop/Kerri/SNHU - 1452874/22EW1/CS330 Comp Graphic and Visualization/OpenGL_Projects/Dependencies/include/ball.jpg", &ballWidth, &ballHeight, 0, SOIL_LOAD_RGB);

	GLuint ballTexture;
	glGenTextures(1, &ballTexture);
	glBindTexture(GL_TEXTURE_2D, ballTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, ballWidth, ballHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, ballImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(ballImage);
	glBindTexture(GL_TEXTURE_2D, 0);


	// -------------------------------------------------------------------

	// Vertex shader source code
	string vertexShaderSource =
		"#version 330 core\n"
		"layout(location = 0) in vec3 vPosition;"
		"layout(location = 1) in vec3 aColor;"
		"layout(location = 2) in vec2 texCoord;"
		"layout(location = 3) in vec3 normal;"
		"out vec3 oColor;"
		"out vec2 oTexCoord;"
		"out vec3 oNormal;"
		"out vec3 FragPos;"
		"uniform mat4 model;"
		"uniform mat4 view;"
		"uniform mat4 projection;"
		"void main()\n"
		"{\n"
		"gl_Position = projection * view * model * vec4(vPosition.x, vPosition.y, vPosition.z, 1.0f);"
		"oColor = aColor;"
		"oTexCoord = texCoord;"
		"oNormal = mat3(transpose(inverse(model))) * normal;" // transpose is for scaling; remove if not using
		"FragPos = vec3(model * vec4(vPosition, 1.0f));"
		"}\n";



	// Fragment shader source code
	string fragmentShaderSource =
		"#version 330 core\n"
		"in vec3 oColor;"
		"in vec2 oTexCoord;"
		"in vec3 oNormal;"
		"in vec3 FragPos;"
		"out vec4 fragColor;"
		"uniform sampler2D myTexture;"
		"uniform vec3 objectColor;"
		"uniform vec3 lightColor1;"
		"uniform vec3 lightPos1;"
		"uniform vec3 lightColor2;"
		"uniform vec3 lightPos2;"
		"uniform vec3 viewPos;"
		"void main()\n"
		"{\n"
		"//Ambient\n"
		"float ambientStrength = 0.6f;"
		"float ambientStrength2 = 0.5f;"
		"vec3 ambient = ambientStrength * lightColor1;"
		"vec3 ambient2 = ambientStrength2 * lightColor2;"
		"//Diffuse\n"
		"vec3 norm = normalize(oNormal);"
		"vec3 lightDir1 = normalize(lightPos1 - FragPos);"
		"vec3 lightDir2 = normalize(lightPos2 - FragPos);"
		"float diff1 = max(dot(norm, lightDir1), 0.0);"
		"float diff2 = max(dot(norm, lightDir2), 0.0);"
		"vec3 diffuse1 = diff1 * 3.0 * lightColor1;"
		"vec3 diffuse2 = diff2 * 2.0 * lightColor2;"
		"vec3 totalDiffuse = diffuse1 + diffuse2;"
		"//Specularity\n"
		"float specularStrength1 = 2.0f;"
		"float specularStrength2 = 2.0f;"
		"vec3 viewDir = normalize(viewPos - FragPos);"
		"vec3 reflectDir1 = reflect(-lightDir1, norm);"
		"vec3 reflectDir2 = reflect(-lightDir2, norm);"
		"float spec1 = pow(max(dot(viewDir, reflectDir1), 0.0), 32);"
		"float spec2 = pow(max(dot(viewDir, reflectDir2), 0.0), 32);"
		"vec3 specular1 = specularStrength1 * spec1 * lightColor1;"
		"vec3 specular2 = specularStrength2 * spec2 * lightColor2;"
		"vec3 totalSpecular = specular1 + specular2;"
		"vec3 result = (ambient + ambient2 + totalDiffuse + totalSpecular) * objectColor;"
		"fragColor = texture(myTexture, oTexCoord) * vec4(result, 1.0f);"
		"}\n";


	// First Lamp Vertex shader source code
	string lampVertexShaderSource =
		"#version 330 core\n"
		"layout(location = 0) in vec3 vPosition;"
		"uniform mat4 model;"
		"uniform mat4 view;"
		"uniform mat4 projection;"
		"void main()\n"
		"{\n"
		"gl_Position = projection * view * model * vec4(vPosition.x, vPosition.y, vPosition.z, 1.0f);"
		"}\n";


	// First Lamp Fragment shader source code
	string lampFragmentShaderSource =
		"#version 330 core\n"
		"out vec4 fragColor;"
		"void main()\n"
		"{\n"
		"fragColor = vec4(1.0f, 1.0f, 1.0f, 1.0f);" // Can individually assign RGB values
		"}\n";

	// Second Lamp Vertex shader source code
	string lampVertexShaderSource2 =
		"#version 330 core\n"
		"layout(location = 0) in vec3 vPosition;"
		"uniform mat4 model;"
		"uniform mat4 view;"
		"uniform mat4 projection;"
		"void main()\n"
		"{\n"
		"gl_Position = projection * view * model * vec4(vPosition.x, vPosition.y, vPosition.z, 1.0f);"
		"}\n";


	// Second Lamp Fragment shader source code
	string lampFragmentShaderSource2 =
		"#version 330 core\n"
		"out vec4 fragColor;"
		"void main()\n"
		"{\n"
		"fragColor = vec4(1.0f, 1.0f, 0.0f, 0.0f);" // Can individually assign RGB values
		"}\n";


	// Creating Shader Program
	GLuint shaderProgram = CreateShaderProgram(vertexShaderSource, fragmentShaderSource);
	GLuint lampShaderProgram = CreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource);
	GLuint lampShaderProgram2 = CreateShaderProgram(lampVertexShaderSource2, lampFragmentShaderSource2);


	// --- RENDER LOOP ---------------------------------------------------------------------------------

	/* Loop until the user closes the window */
	while (!glfwWindowShouldClose(window))
	{
		// Set frame time
		float currentFrame = glfwGetTime();
		gDeltaTime = currentFrame - gLastFrame;
		gLastFrame = currentFrame;

		// input
		//ProcessInput(window);

		// Resize window and graphics simultaneously
		glfwGetFramebufferSize(window, &width, &height);
		glViewport(0, 0, width, height);


		/* Render here */
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Use Shader Program exe and select VAO before drawing 
		glUseProgram(shaderProgram); // Call Shader per-frame when updating attributes


		// Declare transformations (can be initialized outside loop)		
		glm::mat4 projectionMatrix;

		// Define LookAt Matrix
		viewMatrix = glm::lookAt(cameraPosition, target, worldUp);

		// Define projection matrix
		projectionMatrix = glm::perspective(fov, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);

		if (perspective == false) {
			projectionMatrix = glm::perspective(glm::radians(cameraZoom), (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);
		}

		else if (perspective == true) {
			projectionMatrix = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
		}


		// Get matrix's uniform location and set matrix
		GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
		GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
		GLint projLoc = glGetUniformLocation(shaderProgram, "projection");

		// Get light and object color location + light position location
		GLint objectColorLoc = glGetUniformLocation(shaderProgram, "objectColor");
		GLint lightColorLoc1 = glGetUniformLocation(shaderProgram, "lightColor1");
		GLint lightPosLoc1 = glGetUniformLocation(shaderProgram, "lightPos1");
		GLint lightColorLoc2 = glGetUniformLocation(shaderProgram, "lightColor2");
		GLint lightPosLoc2 = glGetUniformLocation(shaderProgram, "lightPos2");
		GLint viewPosLoc = glGetUniformLocation(shaderProgram, "viewPos");

		// Assign Light and Object Colors
		glUniform3f(objectColorLoc, 1.0f, 1.0f, 1.0f); // RGB: 0.19f, 0.12f, 0.11f
		glUniform3f(lightColorLoc1, 1.0f, 1.0f, 1.0f);
		glUniform3f(lightColorLoc2, 1.0f, 1.0f, 0.0f);

		// Set Light Position
		glUniform3f(lightPosLoc1, lightPosition1.x, lightPosition1.y, lightPosition1.z);
		glUniform3f(lightPosLoc2, lightPosition2.x, lightPosition2.y, lightPosition2.z);

		// Specify view/camera Position
		glUniform3f(viewPosLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

		// Pass transform to Shader
		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));






		/***************************** SETTING UP LAMP ONE ****************************/

		glUseProgram(0); // Incase different shader will be used after

		glUseProgram(lampShaderProgram); // Call lamp shader program

			// Get matrix's uniform location and set matrix
		GLint lampModelLoc = glGetUniformLocation(lampShaderProgram, "model");
		GLint lampViewLoc = glGetUniformLocation(lampShaderProgram, "view");
		GLint lampProjLoc = glGetUniformLocation(lampShaderProgram, "projection");

		// Pass transform to Shader
		glUniformMatrix4fv(lampViewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));
		glUniformMatrix4fv(lampProjLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));



		/********************** START DRAWING LAMP ONE *********************/

		glBindVertexArray(lampVAO); // User-defined VAO must be called before draw. 

		// Lamp One

		for (GLuint i = 0; i < 1; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, torus_planePositions[i] / glm::vec3(8.0f, 8.0f, 8.0f) + lightPosition1);
			modelMatrix = glm::rotate(modelMatrix, torus_planeRotations[i] * toRadians, glm::vec3(1.0f, 1.0f, 1.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 1.0f));
			if (i >= 1)
				modelMatrix = glm::rotate(modelMatrix, torus_planeRotations[i] * toRadians, glm::vec3(1.0f, 1.0f, 1.0f));

			glUniformMatrix4fv(lampModelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			// Draw primitive(s)
			//cube_draw();
			light_draw(16,16);
		}


		/********************* STOP DRAWING LAMP ONE *********************/







		/***************************** SETTING UP LAMP TWO ****************************/


		glUseProgram(0); // Incase different shader will be used after

		glUseProgram(lampShaderProgram2); // Call lamp shader program

			// Get matrix's uniform location and set matrix
		GLint lampModelLoc2 = glGetUniformLocation(lampShaderProgram2, "model");
		GLint lampViewLoc2 = glGetUniformLocation(lampShaderProgram2, "view");
		GLint lampProjLoc2 = glGetUniformLocation(lampShaderProgram2, "projection");

		// Pass transform to Shader
		glUniformMatrix4fv(lampViewLoc2, 1, GL_FALSE, glm::value_ptr(viewMatrix));
		glUniformMatrix4fv(lampProjLoc2, 1, GL_FALSE, glm::value_ptr(projectionMatrix));


		/********************** START DRAWING LAMP TWO *********************/

		glBindVertexArray(lampVAO); // User-defined VAO must be called before draw. 

		// Lamp Two:

		// Draws ball
		for (int i = 0; i < 1; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.5f, 0.5f, 1.0f));
			modelMatrix = glm::rotate(modelMatrix, glm::radians(90.f), glm::vec3(1.0f, 0.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.2f, 0.2f, 0.2f));

			GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			ball_draw();
		}

				glBindVertexArray(0);
				glUseProgram(0); // Incase different shader will be used after


		/********************* STOP DRAWING LAMP TWO *********************/





		//********************** START DICE DRAWING /**********************/

		glUseProgram(lampShaderProgram); // Call lamp shader program
		glUseProgram(shaderProgram); // Call Shader per-frame when updating attributes


		glBindTexture(GL_TEXTURE_2D, diceTexture);
		glBindVertexArray(diceVAO); // User-defined VAO must be called before draw. 

			// Draws the triangles
		for (int i = 0; i < 1; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, glm::vec3(0.3f, -0.42f, 1.2f));
			modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.06f, 0.06f, 0.06f));
			if (i >= 1)
				modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));

			GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			dice_draw();
		}

		// Unbind Shader exe and VAO after drawing per frame

		glBindVertexArray(0);
		glUseProgram(0); // Incase different shader will be used after
		glDisable(GL_TEXTURE_2D);

		//********************** STOP DICE DRAWING /**********************/




		/**************************** START TABLE DRAWING ****************************/

		// Select and transform table
		glBindVertexArray(tableVAO);
		glBindTexture(GL_TEXTURE_2D, tableTexture);

		glUseProgram(lampShaderProgram); // Call lamp shader program
		glUseProgram(shaderProgram); // Call Shader per-frame when updating attributes


		for (int i = 0; i < 4; i++) {
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0f, 1.5f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, 0.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(1.0f, 1.0f, 1.0f));


			GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			GLint lampModelLoc = glGetUniformLocation(lampShaderProgram, "model");
			glUniformMatrix4fv(lampModelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			table_draw();
		}

		glBindVertexArray(0); // Incase different VAO will be used after
		glUseProgram(0); // Incase different shader will be used after
		glDisable(GL_TEXTURE_2D);

		/**************************** END TABLE DRAWING ****************************/





		/**************************** START BOTTLE BASE DRAWING ****************************/

		glUseProgram(lampShaderProgram); // Call lamp shader program
		glUseProgram(shaderProgram); // Call Shader per-frame when updating attributes

		glBindVertexArray(bottleVAO);
		glBindTexture(GL_TEXTURE_2D, bottleTexture);


		for (int i = 0; i < 6; i++) {
			glm::float32 triRotations[] = { 0.0f, 60.0f, 120.0f, 180.0f, 240.0f, 300.0f };
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(0.3f, 0.2f, 0.0f)); // Position strip at 0,0,0
			modelMatrix = glm::translate(modelMatrix, glm::vec3(-0.2f, 0.0f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, glm::radians(-90.f), glm::vec3(1.0f, 0.0f, 0.0f)); // Rotate strip 60 deg on x (z is now almost upright, and y rotates toward z)
			modelMatrix = glm::rotate(modelMatrix, glm::radians(triRotations[i]), glm::vec3(0.0f, 0.0f, 1.0f)); // Rotate strip on z by increments in array		
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.18f, 0.18f, 0.36f));

			//Copy perspective and MV matrices to uniforms

			GLint modelLoc = glGetUniformLocation(shaderProgram, "model");

			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

			GLint lampModelLoc = glGetUniformLocation(lampShaderProgram, "model");
			glUniformMatrix4fv(lampModelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			glDrawArrays(GL_TRIANGLES, 0, 120); // Render primitive or execute shader per draw

		}

		glBindVertexArray(0); // Incase different VAO will be used after
		glUseProgram(0); // Incase different shader will be used after
		glDisable(GL_TEXTURE_2D);


		/**************************** END BOTTLE BASE DRAWING ****************************/




		/**************************** START BOTTLE TOP DRAWING ****************************/

		glUseProgram(lampShaderProgram); // Call lamp shader program
		glUseProgram(shaderProgram); // Call Shader per-frame when updating attributes

		glBindVertexArray(capVAO);
		glBindTexture(GL_TEXTURE_2D, capTexture);


		for (int i = 0; i < 6; i++) {
			glm::float32 triRotations[] = { 0.0f, 60.0f, 120.0f, 180.0f, 240.0f, 300.0f, 360.0f };
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(0.3f, 0.23f, 0.0f)); // Position strip at 0,0,0
			modelMatrix = glm::translate(modelMatrix, glm::vec3(-0.2f, 0.0f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, glm::radians(-90.f), glm::vec3(1.0f, 0.0f, 0.0f)); // Rotate strip 60 deg on x (z is now almost upright, and y rotates toward z)
			modelMatrix = glm::rotate(modelMatrix, glm::radians(triRotations[i]), glm::vec3(0.0f, 0.0f, 1.0)); // Rotate strip on z by increments in array		
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.08f, 0.08f, 0.08f));

			//Copy perspective and MV matrices to uniforms

			GLint modelLoc = glGetUniformLocation(shaderProgram, "model");

			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

			GLint lampModelLoc = glGetUniformLocation(lampShaderProgram, "model");
			glUniformMatrix4fv(lampModelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			glDrawArrays(GL_TRIANGLE_STRIP, 0, 180); // Render primitive or execute shader per draw

		}

		glBindVertexArray(0); // Incase different VAO will be used after
		glUseProgram(0); // Incase different shader will be used after
		glDisable(GL_TEXTURE_2D);

		/**************************** END BOTTLE TOP DRAWING ****************************/





		/********************* START DRAWING NECK PILLOW *********************/

		glUseProgram(shaderProgram); // Call Shader per-frame when updating attributes
		//glUseProgram(lampShaderProgram); // Call lamp shader program
	
		glBindTexture(GL_TEXTURE_2D, pillowTexture);

		// Draws torus
		for (int i = 0; i < 2; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, glm::vec3(0.3f, -0.25f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, glm::radians(-120.0f), glm::vec3(1.0f, 1.0f, 1.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 1.0f, 3.0f));

			GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			
			pillow_draw(36,36);
		}

		glUseProgram(0); // Incase different shader will be used after
		glDisable(GL_TEXTURE_2D);

		/********************* STOP DRAWING NECK PILLOW *********************/






		/********************* START DRAWING BALL *********************/

		glUseProgram(shaderProgram); // Call Shader per-frame when updating attributes
		//glUseProgram(lampShaderProgram); // Call lamp shader program

		glBindTexture(GL_TEXTURE_2D, ballTexture);

		// Draws ball
		for (int i = 0; i < 1; i++)
		{
			glm::mat4 modelMatrix;
			modelMatrix = glm::translate(modelMatrix, glm::vec3(-0.5f, -0.2f, 1.0f));
			modelMatrix = glm::rotate(modelMatrix, glm::radians(90.f), glm::vec3(1.0f, 0.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.3f, 0.3f, 0.3f));

			GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			ball_draw();
		}

		glUseProgram(0); // Incase different shader will be used after
		glDisable(GL_TEXTURE_2D);

		/********************* STOP DRAWING BALL *********************/



		/* Swap front and back buffers */
		glfwSwapBuffers(window);

		/* Poll for and process events */
		glfwPollEvents();

		// Poll Camera Transformations
		TransformCamera();
	}

	//Clear GPU resources
	glDeleteVertexArrays(1, &diceVAO);
	glDeleteBuffers(1, &diceVBO);
	glDeleteBuffers(1, &diceEBO);
	glDeleteVertexArrays(1, &lampVAO);
	glDeleteBuffers(1, &lampVBO);
	glDeleteBuffers(1, &lampEBO);
	glDeleteVertexArrays(1, &tableVAO);
	glDeleteBuffers(1, &tableVBO);
	glDeleteBuffers(1, &tableEBO);
	glDeleteVertexArrays(1, &bottleVAO);
	glDeleteBuffers(1, &bottleVBO);
	glDeleteVertexArrays(1, &capVAO);
	glDeleteBuffers(1, &capVBO);
	glDeleteVertexArrays(1, &lampVAO);
	glDeleteBuffers(1, &lampVBO);



	glfwTerminate();
	return 0;
}



/*--- CAMERA AND INPUT SETUP ----------------------------------------------------------------------------*/
// Establish camera and input settings

void ProcessKeyboard(Camera_Movement direction, float gDeltaTime)
{
	static const float cameraSpeed = 2.5f;
	float velocity = cameraSpeed * gDeltaTime;

	if (direction == FORWARD)
		cameraPosition += cameraFront * velocity;
	if (direction == BACKWARD)
		cameraPosition -= cameraFront * velocity;
	if (direction == LEFT)
		cameraPosition -= cameraRight * velocity;
	if (direction == RIGHT)
		cameraPosition += cameraRight * velocity;
	if (direction == UP)
		cameraPosition += cameraUp * velocity;
	if (direction == DOWN)
		cameraPosition -= cameraUp * velocity;
}

// Define getTarget function
glm::vec3 getTarget() {
	if (isPanning == true)
		target = cameraPosition + cameraFront;
	return target;
}

// Define input functions
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (action == GLFW_PRESS) {
		keys[key] = true;
	}
	else if (action == GLFW_RELEASE) {
		keys[key] = false;
	}

	static const float cameraSpeed = 20.0f;
	float cameraOffset = cameraSpeed * gDeltaTime;

	// Move Forward
	if (keys[window, GLFW_KEY_W]) {
		ProcessKeyboard(FORWARD, gDeltaTime);
		cameraPosition += cameraOffset * cameraFront;
	}

	// Move Backwards
	if (keys[GLFW_KEY_A]) {
		ProcessKeyboard(LEFT, gDeltaTime);
		cameraPosition -= cameraOffset * cameraRight;
	}

	// Move Left
	if (keys[GLFW_KEY_S]) {
		ProcessKeyboard(BACKWARD, gDeltaTime);
		cameraPosition -= cameraOffset * cameraFront;
	}

	// Move Right
	if (keys[GLFW_KEY_D]) {
		ProcessKeyboard(RIGHT, gDeltaTime);
		cameraPosition += cameraOffset * cameraRight;
	}

	// Move Up
	if (keys[GLFW_KEY_Q]) {
		ProcessKeyboard(UP, gDeltaTime);
		cameraPosition += cameraOffset * cameraUp;
	}

	// Move Down
	if (keys[GLFW_KEY_E]) {
		ProcessKeyboard(DOWN, gDeltaTime);
		cameraPosition -= cameraOffset * cameraUp;
	}

	// Reset Camera
	if (keys[GLFW_KEY_F]) {
		initCamera();
	}

	// Change from perspective to orthographic (and vice versa)

	if (keys[window, GLFW_KEY_P] == GLFW_PRESS) {
		perspective = true; // Hold P for orthographic view
	}
	
	if (keys[window, GLFW_KEY_P] == GLFW_RELEASE) {
		perspective = false; // Back to perspective when released
	}

}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	if (fov >= fovMIN && fov <= fovMAX) {
		fov -= yoffset * SCROLL_SPEED;
	}

	// Clamp FOV
	if (fov < fovMIN) {
		fov = fovMIN;
	}

	if (fov > fovMAX) {
		fov = fovMAX;
	}
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos) {
	static const float cameraSpeed = 2.5f;

	if (firstMouseMove)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouseMove = false;
	}

	// Calculate cursor offset
	xChange = xpos - lastX;
	yChange = lastY - ypos;

	lastX = xpos;
	lastY = ypos;

	// Pan camera
	if (isPanning == true) {
		GLfloat cameraSpeed = xChange * gDeltaTime;
		cameraPosition += cameraSpeed * cameraRight;

		cameraSpeed = yChange * gDeltaTime;
		cameraPosition += cameraSpeed * cameraUp;
	}

	// Orbit camera
	if (isOrbiting == true) {
		rawYaw += xChange;
		rawPitch += yChange;

		// Convert Yaw and Pitch to Degrees
		degYaw = glm::radians(rawYaw);
		degPitch = glm::clamp(glm::radians(rawPitch), -glm::pi<float>() / 2.0f + 0.1f, glm::pi<float>() / 2.0f - 0.1f);

		// Azimuth Altitude Formula
		cameraPosition.x = target.x + radius * cosf(degPitch) * sinf(degYaw);
		cameraPosition.y = target.y + radius * sinf(degPitch);
		cameraPosition.z = target.z + radius * cosf(degYaw) * cosf(degYaw);
	}

}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mode)
{
	if (action == GLFW_PRESS)
		mouseButton[button] = true;

	else if (action == GLFW_RELEASE)
		mouseButton[button] = false;


}

// Define TransformCamera function
void TransformCamera()
{

	// Orbit camera
	if (keys[GLFW_KEY_LEFT_ALT] && mouseButton[GLFW_MOUSE_BUTTON_LEFT]) {
		isOrbiting = true;
	}
	else {
		isOrbiting = false;
	}

	// Pan camera
	if (keys[GLFW_KEY_LEFT_ALT] && mouseButton[GLFW_MOUSE_BUTTON_RIGHT]) {
		isPanning = true;
	}
	else {
		isPanning = false;
	}


	// Reset camera
	if (keys[GLFW_KEY_F]) {
		initCamera();
	}

}

// Define 
void initCamera()
{	// Define Camera Attributes
	cameraPosition = glm::vec3(0.0f, 0.0f, 3.0f); // Move 3 units back in z towards screen
	target = glm::vec3(0.0f, 0.0f, 0.0f); // What the camera points to
	cameraDirection = glm::normalize(cameraPosition - cameraDirection); // direction z
	worldUp = glm::vec3(0.0, 1.0f, 0.0f);
	cameraRight = glm::normalize(glm::cross(worldUp, cameraDirection));// right vector x
	cameraUp = glm::normalize(glm::cross(cameraDirection, cameraRight)); // up vector y
	cameraFront = glm::vec3(0.0f, 0.0f, -1.0f); // 1 unit away from lense
}
